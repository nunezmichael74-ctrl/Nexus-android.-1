# Nexus para Android

App nativa de Android (Android 8.0 o superior) que contiene Nexus Knowledge completa y funciona
sin conexión: votos, respuestas aceptadas, reputación, búsqueda, historia y proyectos. Los datos se
guardan en el móvil.

## Opción A — Compilar en GitHub (sin instalar nada)

1. Crea una cuenta gratuita en github.com si no la tienes.
2. Crea un repositorio nuevo: **New repository** → nombre `nexus-android` → **Private** → **Create**.
3. En el repositorio, pulsa **uploading an existing file** y arrastra **todo el contenido** de la
   carpeta `nexus-android` (también la carpeta `.github`; en Windows, activa «ver archivos ocultos»).
   Pulsa **Commit changes**.
4. Abre la pestaña **Actions**: la compilación «APK Android» empieza sola y tarda unos 4 minutos.
   Si GitHub pide activar Actions, pulsa **I understand… enable**.
5. Cuando termine (marca verde), en la página principal del repositorio aparece **Releases** a la
   derecha. Desde el móvil, abre esa Release y descarga `Nexus-1.0.1.apk`.
6. Abre el archivo descargado. Android pedirá permitir **instalar apps de origen desconocido** para
   el navegador o el gestor de archivos: actívalo solo para esta instalación y pulsa **Instalar**.

Cada vez que cambies algo y hagas commit, se genera una versión nueva en Releases.

## Opción B — Android Studio (en tu ordenador)

1. Instala Android Studio (developer.android.com/studio).
2. **File → Open** → carpeta `nexus-android`. Espera a que termine «Gradle sync».
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. Pulsa **locate**: el APK está en `app/build/outputs/apk/debug/app-debug.apk`. Pásalo al móvil
   (cable, Drive o Telegram) e instálalo como en el paso 6.

O con el móvil conectado por USB y la depuración USB activada: botón ▶ **Run**.

## Actualizar sin desinstalar (opcional)

Sin clave propia, cada APK de GitHub se firma con una clave de depuración distinta y, para instalar
una versión nueva, hay que desinstalar la anterior (se pierden los datos de la demo). Para evitarlo,
crea una clave una vez (necesitas Java o Android Studio):

```bash
keytool -genkeypair -v -keystore nexus.jks -alias nexus -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 nexus.jks > nexus.jks.b64      # en Windows: certutil -encode nexus.jks nexus.jks.b64
```

En GitHub: **Settings → Secrets and variables → Actions → New repository secret**:
`NEXUS_KEYSTORE_BASE64` (contenido de `nexus.jks.b64`), `NEXUS_KEYSTORE_PASSWORD`,
`NEXUS_KEY_ALIAS` (`nexus`) y `NEXUS_KEY_PASSWORD`. Guarda `nexus.jks` y sus contraseñas: sin
ellos no podrás publicar actualizaciones de la misma app.

## Qué hay dentro

| Fichero | Para qué |
|---|---|
| `app/src/main/assets/index.html` | La app (la misma que `nexus-knowledge-demo.html`) |
| `app/src/main/java/.../MainActivity.java` | Contenedor nativo: pantalla completa, botón Atrás, enlaces externos al navegador |
| `app/src/main/res/` | Icono (la N amarilla sobre azul tinta), tema y nombre «Nexus» |
| `.github/workflows/android.yml` | Compilación automática y publicación del APK |

Para cambiar contenido o diseño, edita `index.html` y vuelve a compilar.
